-- config.lua

application =
{
	content =
	{
		width = 320,
		height = 480,
		scale = "letterbox", -- zoom to fill screen, possibly cropping edges
	},
}